chrome.runtime.onInstalled.addListener(function() {
chrome.contextMenus.create({
  id: "OpenHistory",
  title: "View History", 
  contexts:["all"]
});
chrome.contextMenus.onClicked.addListener(function(info,tab){
    if (info.menuItemId == "OpenHistory") {
        chrome.tabs.create({
            url: "chrome://history/"
        });
    };
});
//passwords context menu
chrome.contextMenus.create({
  id: "OpenPasswords",
  title: "View Passwords", 
  contexts:["all"]
});
chrome.contextMenus.onClicked.addListener(function(info,tab){
    if (info.menuItemId == "OpenPasswords") {
        chrome.tabs.create({
            url: "chrome://settings/passwords/"
        });
    };
});
//downloads context menu
chrome.contextMenus.create({
  id: "OpenDownloads",
  title: "View Downloads", 
  contexts:["all"]
});
chrome.contextMenus.onClicked.addListener(function(info,tab){
    if (info.menuItemId == "OpenDownloads") {
        chrome.tabs.create({
            url: "chrome://downloads/"
        });
    };
});
});