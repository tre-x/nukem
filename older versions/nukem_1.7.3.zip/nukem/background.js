//NUKEM VERSION 1.7.1 (c) THE VIGILANTE DEVELOPER 2017 
//SEE POLICY.TXT FOR MORE DETAILS
//MAIN SCRIPT
var ko = document.getElementById("kill_option");
var ko2 = document.getElementById("pwd_option");
var ko3 = document.getElementById("cookie_option")
if (ko && ko2 && ko3){
function save_options() {

    localStorage["k_option"] = document.getElementById("kill_option").value;
    localStorage["p_option"] = document.getElementById("pwd_option").value;
    localStorage["c_option"] = document.getElementById("cookie_option").value;
    var status = document.getElementById("status");
    status.innerHTML = "Options Saved";
    setTimeout(function () {
        status.innerHTML = "";
    }, 2000);
}
function restore_options() {
    var o1 = localStorage["k_option"];
    if (o1) {
        document.getElementById("kill_option").value = o1;
    }

    var o2 = localStorage["p_option"];
    if (o2) {
        document.getElementById("pwd_option").value = o2;
    }
    var o3 = localStorage["c_option"];
    if (o3) {
        document.getElementById("cookie_option").value = o3;
    }
}
document.addEventListener('DOMContentLoaded', restore_options);
document.querySelector('#save').addEventListener('click', save_options);
}
var notify_2 = null;
var notify = function () {
    chrome.notifications.create("notify_user", {
        type:    "basic",
        iconUrl: "assets/icon4.png",
        title:   "Nuke'm",
        message: "All Browsing Data has been nuked!",
    },
    );
};
chrome.browserAction.onClicked.addListener(function(tab) {
   chrome.browsingData.remove({
      }, {
        "appcache": true,
        "cache": true,
        "downloads": true,
        "fileSystems": true,
        "formData": true,
        "history": true,
        "indexedDB": true,
        "localStorage": true,
        "pluginData": true,
        "serverBoundCertificates": true,
        "webSQL": true
}, notify);
var ktabs = localStorage["k_option"];
    var kpwds = localStorage["p_option"];
    var kcookies = localStorage["c_option"];
    if (ktabs == "Yes"){
         chrome.tabs.query({}, function (tabArray) {

        for (var i = 0; i <= tabArray.length-1; i++) {
                chrome.tabs.remove(tabArray[i].id);
        }
              chrome.tabs.create({
            url: "chrome://newtab"
        })});
} else{
    console.log("not clearing tabs")
}
 if (kpwds == "Yes"){
         chrome.browsingData.remove({
            }, {
           "passwords": true
});
} else{
    console.log("not clearing passwords")
}
    if (kcookies == "Yes"){
        chrome.browsingData.remove({
            }, {
           "cookies": true
});
    } else{
        console.log("not clearing cookies")
    }
})

